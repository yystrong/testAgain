/**
 * 对接口的抽象的默认实现,避免用户实现过多方法
 * @author JueYue
 *  2014年6月20日 上午12:09:27
 */
package cn.afterturn.easypoi.handler.impl;