/**
 * 
 */
package cn.afterturn.easypoi.excel.graph.constant;

/**
 * @author xfworld
 * @since 2015-12-30
 * @version 1.0
 * 定义图形类型
 */
public interface ExcelGraphType
{
	public static final Integer LINE_CHART =1;
	public static final Integer SCATTER_CHART =2;
	
}
