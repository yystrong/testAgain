/**
 * 
 */
package cn.afterturn.easypoi.entity.vo;



/**
 * @author xfworld
 * @since 2015-12-31
 * @version 1.0
 * 
 */
public interface MapExcelGraphConstants extends MapExcelConstants
{
	 public final static String MAP_GRAPH_EXCEL_VIEW = "MapGraphExcelView";
	 public final static String GRAPH_DEFINED = "graphDefined";
	 
}
